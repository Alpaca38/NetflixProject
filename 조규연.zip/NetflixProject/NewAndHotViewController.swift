//
//  NewAndHotViewController.swift
//  NetflixProject
//
//  Created by 조규연 on 5/16/24.
//

import UIKit

class NewAndHotViewController: UIViewController {

    @IBOutlet var searchTextField: UITextField!
    @IBOutlet var searchIconImageView: UIImageView!
    @IBOutlet var firstCategoryButton: UIButton!
    @IBOutlet var secondCategoryButton: UIButton!
    @IBOutlet var thirdCategoryButton: UIButton!
    @IBOutlet var firstResultLabel: UILabel!
    @IBOutlet var secondResultLabel: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.navigationController?.navigationBar.topItem?.title = "Hot & New 검색"
        self.navigationController?.navigationBar.titleTextAttributes = [ NSAttributedString.Key.font: UIFont.boldSystemFont(ofSize: 20), NSAttributedString.Key.foregroundColor: UIColor.white ]
        
        self.view.backgroundColor = .black
        
        searchTextField.placeholder = "게임, 시리즈, 영화를 검색하세요..."
        searchTextField.backgroundColor = .gray
        searchTextField.leftViewMode = .always
        searchTextField.leftView = searchIconImageView
        
        searchIconImageView.contentMode = .scaleAspectFit
        searchIconImageView.image = UIImage(systemName: "magnifyingglass")
        searchIconImageView.tintColor = .lightGray
        
        let categoryButtons = [firstCategoryButton, secondCategoryButton, thirdCategoryButton]
        
        categoryButtons.forEach { $0?.layer.cornerRadius = 10 }
        
        firstCategoryButton.setImage(.blue, for: .normal)
        firstCategoryButton.setTitle("공개 예정", for: .normal)
        firstCategoryButton.setTitleColor(.white, for: .normal)
        firstCategoryButton.titleLabel?.font = .systemFont(ofSize: 14)
        
        
        secondCategoryButton.setImage(.turquoise, for: .normal)
        secondCategoryButton.setTitle("모두의 인기 콘텐츠", for: .normal)
        secondCategoryButton.setTitleColor(.white, for: .normal)
        secondCategoryButton.titleLabel?.font = .systemFont(ofSize: 14)
        
        thirdCategoryButton.setImage(.pink, for: .normal)
        thirdCategoryButton.setTitle("TOP 10 시리즈", for: .normal)
        thirdCategoryButton.setTitleColor(.white, for: .normal)
        thirdCategoryButton.titleLabel?.font = .systemFont(ofSize: 14)
        
        firstResultLabel.textColor = .white
        firstResultLabel.textAlignment = .center
        firstResultLabel.text = ""
        
        secondResultLabel.textColor = .white
        secondResultLabel.textAlignment = .center
        secondResultLabel.numberOfLines = 0
        secondResultLabel.text = ""
    }
    
    @IBAction func firstCategoryButtonTapped(_ sender: UIButton) {
        firstCategoryButton.setTitleColor(.black, for: .normal)
        secondCategoryButton.setTitleColor(.white, for: .normal)
        thirdCategoryButton.setTitleColor(.white, for: .normal)
        
        firstCategoryButton.backgroundColor = .white
        secondCategoryButton.backgroundColor = .black
        thirdCategoryButton.backgroundColor = .black
        
        firstResultLabel.text = "이런! 찾으시는 작품이 없습니다."
        secondResultLabel.text = "다른 영화, 시리즈, 배우, 감독 또는 장르를 검색해 보세요."
    }
    
    @IBAction func secondCategoryButtonTapped(_ sender: UIButton) {
        firstCategoryButton.setTitleColor(.white, for: .normal)
        secondCategoryButton.setTitleColor(.black, for: .normal)
        thirdCategoryButton.setTitleColor(.white, for: .normal)
        
        firstCategoryButton.backgroundColor = .black
        secondCategoryButton.backgroundColor = .white
        thirdCategoryButton.backgroundColor = .black
        
        firstResultLabel.text = "이런! 인기 콘텐츠가 없습니다."
        secondResultLabel.text = "다음달을 기대해 주세요."
    }
    
    @IBAction func thirdCategoryButtonTapped(_ sender: UIButton) {
        firstCategoryButton.setTitleColor(.white, for: .normal)
        secondCategoryButton.setTitleColor(.white, for: .normal)
        thirdCategoryButton.setTitleColor(.black, for: .normal)
        
        firstCategoryButton.backgroundColor = .black
        secondCategoryButton.backgroundColor = .black
        thirdCategoryButton.backgroundColor = .white
        
        firstResultLabel.text = "상위 10개 시리즈 입니다."
        secondResultLabel.text = ""
    }
}
