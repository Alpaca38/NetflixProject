//
//  SavedViewController.swift
//  NetflixProject
//
//  Created by 조규연 on 5/16/24.
//

import UIKit

class SavedViewController: UIViewController {

    @IBOutlet var firstLabel: UILabel!
    @IBOutlet var secondLabel: UILabel!
    @IBOutlet var savedImageView: UIImageView!
    @IBOutlet var settingButton: UIButton!
    @IBOutlet var viewSavedButton: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        self.navigationController?.navigationBar.topItem?.title = "저장한 콘텐츠 목록"
        self.navigationController?.navigationBar.titleTextAttributes = [ NSAttributedString.Key.font: UIFont.boldSystemFont(ofSize: 20), NSAttributedString.Key.foregroundColor: UIColor.white]
        
        self.view.backgroundColor = .black
        
        firstLabel.text = "'나만의 자동 저장' 기능"
        firstLabel.textColor = .white
        firstLabel.textAlignment = .center
        firstLabel.font = .systemFont(ofSize: 20)
        
        secondLabel.text = "취향에 맞는 영화와 시리즈를 자동으로 저장해 드립니다.\n디바이스에 언제나 시청할 콘텐츠가 준비되니 지루할 틈이 없어요."
        secondLabel.textColor = .gray
        secondLabel.textAlignment = .center
        secondLabel.font = .systemFont(ofSize: 14)
        secondLabel.numberOfLines = 0
        
        savedImageView.image = .dummy
        
        settingButton.setTitle("설정하기", for: .normal)
        settingButton.setTitleColor(.white, for: .normal)
        settingButton.backgroundColor = .systemBlue
        settingButton.layer.cornerRadius = 5
        settingButton.titleLabel?.font = .boldSystemFont(ofSize: 16)
        
        viewSavedButton.setTitle("저장 가능한 콘텐츠 살펴보기", for: .normal)
        viewSavedButton.setTitleColor(.black, for: .normal)
        viewSavedButton.backgroundColor = .white
        viewSavedButton.layer.cornerRadius = 5
        viewSavedButton.titleLabel?.font = .boldSystemFont(ofSize: 16)
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
