//
//  ViewController.swift
//  NetflixProject
//
//  Created by 조규연 on 5/14/24.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
}
